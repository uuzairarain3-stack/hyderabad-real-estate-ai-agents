// Update broker specialties to be more descriptive
const { getDb, initDb, saveDb } = require('./db');

async function fix() {
  await initDb();
  const db = await getDb();
  
  // Update Zahid Hussain with comprehensive specialties
  db.run("UPDATE brokers SET specialties = 'Flats, Plazas, Plots & Houses — All Societies' WHERE name LIKE '%Zahid%'");
  
  // Update other brokers with descriptive specialties
  db.run("UPDATE brokers SET specialties = 'Flats & Houses — Latifabad, Qasimabad' WHERE name LIKE '%Kamran%'");
  db.run("UPDATE brokers SET specialties = 'Plazas & Commercial — Latifabad' WHERE name LIKE '%Ali Estate%'");
  db.run("UPDATE brokers SET specialties = 'Flats, Plots & Houses — All Areas' WHERE name LIKE '%Javed%'");
  db.run("UPDATE brokers SET specialties = 'Houses & Plots — Qasimabad' WHERE name LIKE '%Abbas%'");
  
  saveDb(db);
  console.log('  ✓ Broker specialties updated to descriptive format');
}
fix().catch(console.error);
