const express = require('express');
const router = express.Router();
const { getDb, queryAll, queryOne } = require('../config/db');

router.get('/', async (req, res) => {
  try {
    const db = await getDb();
    const brokers = queryAll(db, `
      SELECT b.*, GROUP_CONCAT(s.name, ', ') as societies
      FROM brokers b
      LEFT JOIN society_brokers sb ON sb.broker_id = b.id
      LEFT JOIN societies s ON s.id = sb.society_id
      GROUP BY b.id
      ORDER BY b.rating DESC
    `);
    res.json(brokers);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.get('/:id', async (req, res) => {
  try {
    const db = await getDb();
    const broker = queryOne(db, 'SELECT * FROM brokers WHERE id = ?', [req.params.id]);
    if (!broker) return res.status(404).json({ error: 'Not found' });
    const societies = queryAll(db, `
      SELECT s.* FROM societies s
      JOIN society_brokers sb ON sb.society_id = s.id WHERE sb.broker_id = ?
    `, [req.params.id]);
    res.json({ ...broker, societies });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
