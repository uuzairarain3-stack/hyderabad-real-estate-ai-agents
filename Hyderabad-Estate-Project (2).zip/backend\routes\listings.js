const express = require('express');
const router = express.Router();
const { getDb, queryAll } = require('../config/db');

router.get('/', async (req, res) => {
  try {
    const db = await getDb();
    const { type, bedrooms, society_id } = req.query;
    let sql = `
      SELECT l.*, s.name as society_name, s.location as society_location,
             b.name as broker_name, b.phone as broker_phone, b.rating as broker_rating
      FROM listings l
      LEFT JOIN societies s ON s.id = l.society_id
      LEFT JOIN brokers b ON b.id = l.broker_id
      WHERE l.status = 'active'
    `;
    const params = [];

    if (type) { sql += ' AND l.type = ?'; params.push(type); }
    if (bedrooms) { sql += ' AND l.bedrooms = ?'; params.push(parseInt(bedrooms)); }
    if (society_id) { sql += ' AND l.society_id = ?'; params.push(parseInt(society_id)); }

    sql += ' ORDER BY l.id DESC';
    const listings = queryAll(db, sql, params);
    res.json(listings);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
