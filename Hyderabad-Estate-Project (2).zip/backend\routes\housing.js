const express = require('express');
const router = express.Router();
const { getDb, queryAll } = require('../config/db');

// GET /api/housing — all housing societies
router.get('/', async (req, res) => {
  try {
    const db = await getDb();
    const rows = queryAll(db, 'SELECT * FROM housing_societies ORDER BY id ASC');
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/housing/:id — single housing society
router.get('/:id', async (req, res) => {
  try {
    const db = await getDb();
    const rows = queryAll(db, 'SELECT * FROM housing_societies WHERE id = ?', [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
