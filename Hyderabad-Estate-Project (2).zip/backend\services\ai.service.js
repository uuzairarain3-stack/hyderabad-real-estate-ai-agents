const { getDb } = require('../config/db');

const SYSTEM_PROMPT = `You are "Hyderabad Estate AI Agent" — a friendly, expert VIP real estate consultant for Hyderabad, Sindh, Pakistan. You work for Zahid Hussain Al Habib Real Estate, the top-rated VIP agency.

IDENTITY:
- Name: Hyderabad Estate AI Agent
- Persona: Professional, friendly, helpful, like a knowledgeable real estate friend
- Language: Naturally code-switch between English and Roman Urdu based on how the user speaks.
- If user writes in English, respond in English.
- If user writes in Roman Urdu or Urdu, respond in Roman Urdu mixed with English real estate terms.
- If user writes in Hindi, Chinese, Arabic, or any other language — respond in that language!

GREETINGS:
- If user says Salam/Assalam u Alaikum/AoA: Greet back warmly as a Muslim: "Walaikum Assalam! Hyderabad Estate mein khush aamdeed. Main aapka AI Real Estate Agent hoon. Kisay madad kar sakta hoon aaj?"
- If user says Hello/Hi/Good morning etc: Reply warmly: "Hello! Welcome to Hyderabad Estate VIP Platform. How can I assist you today?"
- Treat users like intelligent, respected people — never robotic, always warm and human.

KNOWLEDGE:
You know about 20 premium buildings/apartments in Hyderabad:
1. Boulevard Heights (Auto Bhan Road, Latifabad) — 2/3-Bed, Rent: 35k-50k/60k-85k, Sale: 85L-1.2Cr/1.4Cr-2.1Cr
2. Royal Tower & Plaza (Qasimabad) — 2/3-Bed, Rent: 30k-45k/50k-70k, Sale: 75L-1Cr/1.2Cr-1.7Cr
3. Citizen Plaza (Qasimabad) — 2-Bed, Rent: 25k-38k, Sale: 60L-85L
4. Latifabad Unit 7 Plazas — Rent: 28k-40k/45k-65k, Sale: 65L-90L/1.1Cr-1.5Cr
5. Abdullah Heights (Qasimabad Bypass) — Rent: 22k-32k/40k-55k, Sale: 55L-75L/90L-1.25Cr
6. Latifabad Unit 3 Flats — Rent: 20k-30k, Sale: 48L-68L
7. Defence Garden Apartments (Cantt/Saddar) — Rent: 40k-55k/65k-90k, Sale: 95L-1.3Cr/1.5Cr-2.2Cr
8. Al-Rahim Apartments (Wadhu Wah) — Rent: 25k-35k/42k-60k, Sale: 62L-82L/95L-1.35Cr
9. Jumeirah Heights (Qasimabad) — 2-Bed, Rent: 28k-40k, Sale: 70L-95L
10. Hyderabad Centre Plaza — Rent: 32k-45k, Sale: 80L-1.1Cr
11. Palm Apartments (Airport Road) — Rent: 18k-26k/30k-42k, Sale: 42L-60L/70L-95L
12. Gulshan-e-Sajjad Tower — Rent: 26k-36k/45k-62k, Sale: 65L-88L/1Cr-1.4Cr
13. Latifabad Unit 2 Commercial Tower — Rent: 24k-34k, Sale: 58L-78L
14. Saima Reef Apartments — Rent: 22k-32k/38k-52k, Sale: 52L-72L/85L-1.15Cr
15. Al-Mustafa Plaza — Rent: 27k-38k, Sale: 68L-90L
16. Al-Habeeb Tower — Rent: 18k-25k/28k-38k, Sale: 45L-62L/72L-98L
17. Bhittai Tower (Bhittai Town) — Rent: 20k-28k, Sale: 48L-66L
18. City Heights (Jamshoro Road) — Rent: 17k-24k, Sale: 40L-58L
19. Cantonment Plaza (Saddar Bazar) — Rent: 35k-48k, Sale: 85L-1.15Cr
20. Wadhu Wah Avenue Tower — Rent: 30k-42k/52k-75k, Sale: 75L-1Cr/1.25Cr-1.75Cr

HOUSING SOCIETIES (24 plot-based societies):
Gulshan-e-Zealpak, Saima Downtown, Palm Village, Citizen Colony, Revenue Employees, Rohaan Faraz Villas, Sadiq Livna, Gulistan-e-Sarmast (HDA), New Hyderabad City, Daman-e-Kohsar, Naqash Villas, Ink City, Zulfiqar Royal Residency, Gulshan-e-Sajjad, Hyderabad-Badin Road Schemes, Gulshan-e-Shahbaz, Al-Mustafa Town, Al-Rahim Town Phase 2, Al-Habeeb City, Gulshan-e-Iqbal, Qasimabad Phase 1&2, Mehran Town, Green City, Teachers Society.
Plot rates range from PKR 12 Lac to 5 Crore depending on size and society.

VIP BROKER: Zahid Hussain Al Habib Real Estate — 03013501356 (5-Star, Verified VIP)

RESPONSE STYLE:
- Give specific property recommendations with real prices
- Always mention the VIP broker for bookings
- Use bullet points when listing options
- Be specific, confident, and helpful
- If asked about other cities: "Filhal mere paas sirf Hyderabad ke verified properties hain."
- If budget is shared: Suggest top 2-3 matching options
`;

// ---------- GROQ (fast & free Llama/Mixtral) ----------
async function callGroq(messages) {
  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey || !apiKey.startsWith('gsk_')) throw new Error('No Groq key');
  const OpenAI = require('openai');
  const client = new OpenAI({ apiKey, baseURL: 'https://api.groq.com/openai/v1' });
  const response = await client.chat.completions.create({
    model: 'openai/gpt-oss-120b',
    messages: [{ role: 'system', content: SYSTEM_PROMPT }, ...messages],
    max_tokens: 800,
    temperature: 0.7
  });
  return response.choices[0].message.content;
}

// ---------- OPENAI ----------
async function callOpenAI(messages) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey || !apiKey.startsWith('sk-')) throw new Error('No OpenAI key');
  const OpenAI = require('openai');
  const client = new OpenAI({ apiKey });
  const response = await client.chat.completions.create({
    model: 'gpt-4o',
    messages: [{ role: 'system', content: SYSTEM_PROMPT }, ...messages],
    max_tokens: 800,
    temperature: 0.7
  });
  return response.choices[0].message.content;
}

// ---------- LOCAL FALLBACK ----------
function buildLocalResponse(userMessage) {
  const msg = userMessage.toLowerCase();
  if (msg.includes('salam') || msg.includes('salaam') || msg.includes('aoa') || msg.includes('assalam')) {
    return `Walaikum Assalam! 🌟 Hyderabad Estate VIP Platform mein khush aamdeed!\n\nMain aapka AI Real Estate Agent hoon. Hyderabad ke best apartments ke baare mein pooch saktay hain aap. Kya dhundh rahe hain — Rent ke liye ya Sale ke liye?`;
  }
  if (msg.includes('hello') || msg.includes('hi') || msg.includes('hey')) {
    return `Hello! Welcome to Hyderabad Estate VIP Platform! 🏢\n\nI'm your AI Real Estate Agent. I can help you find the perfect apartment in Hyderabad, Sindh. Are you looking for:\n- **Rent** (monthly rental)\n- **Sale** (buying a property)\n\nJust tell me your budget and preferences!`;
  }
  if (msg.includes('luxury') || msg.includes('luxe') || msg.includes('vip')) {
    return `VIP Luxury Apartments in Hyderabad:\n\n⭐ **Defence Garden Apartments** (Saddar Cantt) — Cantonment area, minimal load-shedding, Rent: 40k-90k/month\n⭐ **Boulevard Heights** (Auto Bhan Road) — Mall access, RO plant, generator backup, Rent: 35k-85k/month\n⭐ **Cantonment Plaza** (Saddar Bazar) — Prime commercial + residential, Rent: 35k-48k/month\n\n📞 Contact VIP Broker: **Zahid Hussain Al Habib Real Estate — 03013501356**`;
  }
  if (msg.includes('qasimabad') || msg.includes('qasim')) {
    return `Qasimabad ke top apartments:\n\n🏢 Royal Tower & Plaza — Qasimabad Main Road\n🏢 Citizen Plaza — Citizen Colony\n🏢 Abdullah Heights — Qasimabad Bypass\n🏢 Jumeirah Heights — Jumeirah Town\n🏢 Gulshan-e-Sajjad Tower\n🏢 Wadhu Wah Avenue Tower\n\nQasimabad mein rent range: 22,000 – 75,000/month. Kaunsa area prefer karte hain?`;
  }
  if (msg.includes('latifabad') || msg.includes('latif')) {
    return `Latifabad ke top apartments:\n\n🏢 Boulevard Heights — Auto Bhan Road (Luxury)\n🏢 Latifabad Unit 7 Plazas — Unit 7 Commercial\n🏢 Latifabad Unit 3 Flats — Near Unit 3 Market\n🏢 Saima Reef Apartments — Latifabad Link Road\n\nLatifabad mein rent range: 20,000 – 85,000/month.`;
  }
  if (msg.includes('broker') || msg.includes('contact') || msg.includes('number') || msg.includes('phone')) {
    return `Our VIP Brokers:\n\n⭐⭐⭐⭐⭐ **Zahid Hussain Al Habib Real Estate** — 03013501356 (TOP RATED)\n⭐⭐⭐⭐ **Kamran Broker** — 03133006063\n⭐⭐⭐⭐ **Ali Estate** — 03114044584\n\nFor best service, contact Zahid Hussain directly — verified VIP broker for all 20 properties!`;
  }
  if (msg.includes('housing') || msg.includes('plot') || msg.includes('society') || msg.includes('saima')) {
    return `Hyderabad ki 24 housing societies available hain! Top options:\n\n🏘️ **Saima Downtown** — 1800 plots, 120-240 Sq Yds, 1.10Cr-3.50Cr\n🏘️ **Palm Village** — 1200 plots, Royal gated community\n🏘️ **Citizen Colony** — 850 plots, Qasimabad prime location\n🏘️ **Qasimabad Phase 1&2** — 2500 plots, fully developed\n\n📞 Plot rates ke liye contact karein: **Zahid Hussain — 03013501356**`;
  }
  return `Hyderabad Estate AI Agent yahan hai! Main aapki madad kar sakta hoon:\n\n🔍 **Property dhundna** — budget batayein, areas suggest karoon ga\n🏘️ **Society info** — gas, water, electricity, amenities\n📞 **Broker contact** — verified brokers ke numbers\n💰 **Prices** — current rent & sale rates\n\nAap ka sawaal kya hai? Rent chahiye, sale chahiye, ya kisi area ke baare mein janna chahte hain?`;
}

// ---------- MAIN CHAT ----------
async function chat(messages) {
  // Try Groq first (free, fast, supports all languages)
  try {
    const reply = await callGroq(messages);
    if (reply) return reply;
  } catch (err) {
    console.error('[AI] Groq error:', err.message);
  }

  // Try OpenAI fallback
  try {
    const reply = await callOpenAI(messages);
    if (reply) return reply;
  } catch (err) {
    console.error('[AI] OpenAI error:', err.message);
  }

  // Local fallback
  const lastMsg = messages[messages.length - 1]?.content || '';
  return buildLocalResponse(lastMsg);
}

module.exports = { chat };
