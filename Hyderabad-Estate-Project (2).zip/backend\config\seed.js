require('dotenv').config({ path: require('path').join(__dirname, '..', '..', '.env') });
const { getDb, initDb, saveDb, runQuery } = require('./db');

async function seed() {
  await initDb();
  const db = await getDb();

  // Clear existing data
  db.run('DELETE FROM society_brokers');
  db.run('DELETE FROM listings');
  db.run('DELETE FROM brokers');
  db.run('DELETE FROM societies');

  // ============================================================
  // 20 SOCIETIES / BUILDINGS
  // ============================================================
  const societies = [
    { name: "Boulevard Heights", name_urdu: "بلیورڈ ہائٹس", location: "Auto Bhan Road, Latifabad", type: "2-Bed & 3-Bed Luxury Apartments", rent_2bed_min: 35000, rent_2bed_max: 50000, rent_3bed_min: 60000, rent_3bed_max: 85000, sale_2bed_min: 8500000, sale_2bed_max: 12000000, sale_3bed_min: 14000000, sale_3bed_max: 21000000, sui_gas: "Fully Active (24/7)", water_supply: "WASA Direct Supply + Dedicated RO Plant Backup", electricity: "HESCO (1-2 Hours/day + Standby Generator)", amenities: "Lifts, Basement Parking, Auto Bhan Mall Access, CCTV Security", latitude: 25.3910, longitude: 68.3520, featured: 1 },
    { name: "Royal Tower & Plaza", name_urdu: "رائل ٹاور اینڈ پلازہ", location: "Qasimabad Main Road", type: "2-Bed & 3-Bed Executive Apartments", rent_2bed_min: 30000, rent_2bed_max: 45000, rent_3bed_min: 50000, rent_3bed_max: 70000, sale_2bed_min: 7500000, sale_2bed_max: 10000000, sale_3bed_min: 12000000, sale_3bed_max: 17000000, sui_gas: "Active Main Line Connection", water_supply: "WASA Filtered Line + Overhead Storage Tanks", electricity: "HESCO (2 Hours/day)", amenities: "High-Speed Passenger Lifts, Mosque Inside Plaza, Commercial Shops", latitude: 25.4200, longitude: 68.3300, featured: 1 },
    { name: "Citizen Plaza", name_urdu: "سٹیزن پلازہ", location: "Citizen Colony, Qasimabad", type: "2-Bed Residential Flats & Commercial Ground Shops", rent_2bed_min: 25000, rent_2bed_max: 38000, rent_3bed_min: null, rent_3bed_max: null, sale_2bed_min: 6000000, sale_2bed_max: 8500000, sale_3bed_min: null, sale_3bed_max: null, sui_gas: "Fully Active", water_supply: "WASA Supply + Underground Boring System", electricity: "HESCO (2 Hours/day)", amenities: "Main Boulevard Facing, Near Gymkhana & Parks, CCTV Security", latitude: 25.4180, longitude: 68.3350, featured: 0 },
    { name: "Latifabad Unit 7 Plazas", name_urdu: "لطیف آباد یونٹ 7 پلازہ", location: "Unit 7 Commercial Area, Latifabad", type: "2-Bed & 3-Bed Family Flats", rent_2bed_min: 28000, rent_2bed_max: 40000, rent_3bed_min: 45000, rent_3bed_max: 65000, sale_2bed_min: 6500000, sale_2bed_max: 9000000, sale_3bed_min: 11000000, sale_3bed_max: 15000000, sui_gas: "Active High Pressure", water_supply: "WASA Direct Line (24/7 High Pressure)", electricity: "HESCO (1-2 Hours/day)", amenities: "School & Hospital Proximity, Mosque Nearby, Commercial Frontage", latitude: 25.3930, longitude: 68.3480, featured: 0 },
    { name: "Abdullah Heights", name_urdu: "عبداللہ ہائٹس", location: "Qasimabad Bypass Road", type: "2-Bed & 3-Bed Modern Apartments", rent_2bed_min: 22000, rent_2bed_max: 32000, rent_3bed_min: 40000, rent_3bed_max: 55000, sale_2bed_min: 5500000, sale_2bed_max: 7500000, sale_3bed_min: 9000000, sale_3bed_max: 12500000, sui_gas: "Pipeline Connected", water_supply: "WASA Scheduled Supply + Boring Backup", electricity: "HESCO (2-3 Hours/day)", amenities: "Gated Complex, Kids Play Area, Elevator, Security Guards", latitude: 25.4220, longitude: 68.3280, featured: 0 },
    { name: "Latifabad Unit 3 Flats", name_urdu: "لطیف آباد یونٹ 3 فلیٹس", location: "Near Unit 3 Market, Latifabad", type: "2-Bed Standard Residential Flats", rent_2bed_min: 20000, rent_2bed_max: 30000, rent_3bed_min: null, rent_3bed_max: null, sale_2bed_min: 4800000, sale_2bed_max: 6800000, sale_3bed_min: null, sale_3bed_max: null, sui_gas: "Active", water_supply: "WASA Line Water", electricity: "HESCO (2-3 Hours/day)", amenities: "Close to Unit 3 Main Market & Food Street, Mosque Nearby", latitude: 25.3890, longitude: 68.3550, featured: 0 },
    { name: "Defence Garden Apartments", name_urdu: "ڈیفنس گارڈن اپارٹمنٹس", location: "Saddar Cantt Area", type: "2-Bed & 3-Bed Luxury Residency", rent_2bed_min: 40000, rent_2bed_max: 55000, rent_3bed_min: 65000, rent_3bed_max: 90000, sale_2bed_min: 9500000, sale_2bed_max: 13000000, sale_3bed_min: 15000000, sale_3bed_max: 22000000, sui_gas: "Fully Active (24/7)", water_supply: "Cantonment Board Direct Water Line (Filtered)", electricity: "Minimal Cantonment Feeder (0-1 Hour/day)", amenities: "High Security Zone, Dedicated Parking, Jamia Masjid Adjacent", latitude: 25.3800, longitude: 68.3800, featured: 1 },
    { name: "Al-Rahim Apartments", name_urdu: "الرحیم اپارٹمنٹس", location: "Wadhu Wah Road, Qasimabad", type: "2-Bed & 3-Bed Family Apartments", rent_2bed_min: 25000, rent_2bed_max: 35000, rent_3bed_min: 42000, rent_3bed_max: 60000, sale_2bed_min: 6200000, sale_2bed_max: 8200000, sale_3bed_min: 9500000, sale_3bed_max: 13500000, sui_gas: "Active Connection", water_supply: "WASA Water Line + Ground Boring Storage", electricity: "HESCO (2 Hours/day)", amenities: "Automatic Elevators, Gated Boundary, Mosque Plot Adjacent", latitude: 25.4150, longitude: 68.3320, featured: 0 },
    { name: "Jumeirah Heights", name_urdu: "جمیرہ ہائٹس", location: "Jumeirah Town, Qasimabad", type: "2-Bed Luxury Flats", rent_2bed_min: 28000, rent_2bed_max: 40000, rent_3bed_min: null, rent_3bed_max: null, sale_2bed_min: 7000000, sale_2bed_max: 9500000, sale_3bed_min: null, sale_3bed_max: null, sui_gas: "Fully Active", water_supply: "WASA Direct Supply Line", electricity: "HESCO (1-2 Hours/day)", amenities: "Underground Sewerage System, Central Park Nearby, Secure Gate", latitude: 25.4250, longitude: 68.3250, featured: 0 },
    { name: "Hyderabad Centre Plaza", name_urdu: "حیدرآباد سینٹر پلازہ", location: "Auto Bhan Extension", type: "Executive 2-Bed Flats & Commercial Offices", rent_2bed_min: 32000, rent_2bed_max: 45000, rent_3bed_min: null, rent_3bed_max: null, sale_2bed_min: 8000000, sale_2bed_max: 11000000, sale_3bed_min: null, sale_3bed_max: null, sui_gas: "Active Pipeline", water_supply: "WASA Connection + Tanker Backup System", electricity: "HESCO (2 Hours/day)", amenities: "Commercial Showrooms, High-Speed Lift, Main Road Frontage", latitude: 25.3920, longitude: 68.3540, featured: 0 },
    { name: "Palm Apartments", name_urdu: "پام اپارٹمنٹس", location: "National Highway / Airport Road", type: "2-Bed & 3-Bed Apartments", rent_2bed_min: 18000, rent_2bed_max: 26000, rent_3bed_min: 30000, rent_3bed_max: 42000, sale_2bed_min: 4200000, sale_2bed_max: 6000000, sale_3bed_min: 7000000, sale_3bed_max: 9500000, sui_gas: "Underground Network Connected", water_supply: "Ground Boring System Active + Scheduled WASA", electricity: "HESCO (3 Hours/day)", amenities: "Sector Mosque, Commercial Shops on Ground Floor", latitude: 25.3950, longitude: 68.3100, featured: 0 },
    { name: "Gulshan-e-Sajjad Tower", name_urdu: "گلشن سجاد ٹاور", location: "Qasimabad", type: "2-Bed & 3-Bed Residential Flats", rent_2bed_min: 26000, rent_2bed_max: 36000, rent_3bed_min: 45000, rent_3bed_max: 62000, sale_2bed_min: 6500000, sale_2bed_max: 8800000, sale_3bed_min: 10000000, sale_3bed_max: 14000000, sui_gas: "Active", water_supply: "WASA Supply Active", electricity: "HESCO (2 Hours/day)", amenities: "Standby Generator for Lifts, Gated Entry, Mosque Nearby", latitude: 25.4210, longitude: 68.3310, featured: 0 },
    { name: "Latifabad Unit 2 Commercial Tower", name_urdu: "لطیف آباد یونٹ 2 کمرشل ٹاور", location: "Unit 2, Latifabad", type: "2-Bed Flats & Retail Commercial Spaces", rent_2bed_min: 24000, rent_2bed_max: 34000, rent_3bed_min: null, rent_3bed_max: null, sale_2bed_min: 5800000, sale_2bed_max: 7800000, sale_3bed_min: null, sale_3bed_max: null, sui_gas: "Active High Pressure", water_supply: "WASA Water Active", electricity: "HESCO (2 Hours/day)", amenities: "Main Market Hub, Easy Transport Access, Jamia Masjid Facing", latitude: 25.3900, longitude: 68.3560, featured: 0 },
    { name: "Saima Reef Apartments", name_urdu: "سیما ریف اپارٹمنٹس", location: "Latifabad Link Road", type: "2-Bed & 3-Bed Gated Community Flats", rent_2bed_min: 22000, rent_2bed_max: 32000, rent_3bed_min: 38000, rent_3bed_max: 52000, sale_2bed_min: 5200000, sale_2bed_max: 7200000, sale_3bed_min: 8500000, sale_3bed_max: 11500000, sui_gas: "Pipeline Available", water_supply: "WASA Connection + Boring Backup", electricity: "HESCO (2-3 Hours/day)", amenities: "Dedicated CCTV Surveillance, Park Area, Covered Car Parking", latitude: 25.3940, longitude: 68.3470, featured: 0 },
    { name: "Al-Mustafa Plaza", name_urdu: "المصطفیٰ پلازہ", location: "Wadhu Wah Link", type: "2-Bed Townhouse Apartments", rent_2bed_min: 27000, rent_2bed_max: 38000, rent_3bed_min: null, rent_3bed_max: null, sale_2bed_min: 6800000, sale_2bed_max: 9000000, sale_3bed_min: null, sale_3bed_max: null, sui_gas: "Fully Active (24/7 High Pressure)", water_supply: "WASA Filtered Water Direct Line", electricity: "HESCO (1-2 Hours/day)", amenities: "2 Masjids Active Nearby, Family Park Access, Security Gate", latitude: 25.4160, longitude: 68.3340, featured: 0 },
    { name: "Al-Habeeb Tower", name_urdu: "الحبیب ٹاور", location: "Scheme 45 / Airport Link", type: "2-Bed & 3-Bed Budget Apartments", rent_2bed_min: 18000, rent_2bed_max: 25000, rent_3bed_min: 28000, rent_3bed_max: 38000, sale_2bed_min: 4500000, sale_2bed_max: 6200000, sale_3bed_min: 7200000, sale_3bed_max: 9800000, sui_gas: "Active Line", water_supply: "WASA Supply System", electricity: "HESCO (2-3 Hours/day)", amenities: "Community Center Plot, Sector Mosque Built", latitude: 25.3960, longitude: 68.3150, featured: 0 },
    { name: "Bhittai Tower", name_urdu: "بھٹائی ٹاور", location: "Bhittai Town, Qasimabad", type: "2-Bed Standard Residential Flats", rent_2bed_min: 20000, rent_2bed_max: 28000, rent_3bed_min: null, rent_3bed_max: null, sale_2bed_min: 4800000, sale_2bed_max: 6600000, sale_3bed_min: null, sale_3bed_max: null, sui_gas: "Active", water_supply: "WASA Direct Line + Underground Storage", electricity: "HESCO (2-3 Hours/day)", amenities: "Bypass Link Access, Local Market & Mosque Adjacent", latitude: 25.4230, longitude: 68.3290, featured: 0 },
    { name: "City Heights", name_urdu: "سٹی ہائٹس", location: "Jamshoro Road / Bypass Link", type: "2-Bed Modern Flats", rent_2bed_min: 17000, rent_2bed_max: 24000, rent_3bed_min: null, rent_3bed_max: null, sale_2bed_min: 4000000, sale_2bed_max: 5800000, sale_3bed_min: null, sale_3bed_max: null, sui_gas: "Pipeline Installed", water_supply: "Boring Water + WASA Planned Connection", electricity: "HESCO (3 Hours/day)", amenities: "Open Airy View, Gated Gatehouse, Park Frontage", latitude: 25.3850, longitude: 68.3100, featured: 0 },
    { name: "Cantonment Plaza", name_urdu: "کینٹونمنٹ پلازہ", location: "Saddar Bazar Area", type: "2-Bed Commercial & Residential Units", rent_2bed_min: 35000, rent_2bed_max: 48000, rent_3bed_min: null, rent_3bed_max: null, sale_2bed_min: 8500000, sale_2bed_max: 11500000, sale_3bed_min: null, sale_3bed_max: null, sui_gas: "Active Connection (24/7)", water_supply: "Cantonment Board Direct Water Line", electricity: "Cantonment Feeder (0-1 Hour/day)", amenities: "Prime Commercial Location, High Security, Parking Deck", latitude: 25.3810, longitude: 68.3780, featured: 1 },
    { name: "Wadhu Wah Avenue Tower", name_urdu: "واڈھو واہ ایونیو ٹاور", location: "Qasimabad Extension", type: "2-Bed & 3-Bed Luxury Residency", rent_2bed_min: 30000, rent_2bed_max: 42000, rent_3bed_min: 52000, rent_3bed_max: 75000, sale_2bed_min: 7500000, sale_2bed_max: 10000000, sale_3bed_min: 12500000, sale_3bed_max: 17500000, sui_gas: "Fully Active", water_supply: "WASA Direct Filtered Water", electricity: "HESCO (1-2 Hours/day)", amenities: "Lifts, Security Guards, Jamia Masjid & Commercial Strip Adjacent", latitude: 25.4170, longitude: 68.3330, featured: 0 }
  ];

  // ============================================================
  // 38 BROKERS
  // ============================================================
  const brokers = [
    { name: "Zahid Hussain - Al Habib Real Estate", phone: "03013501356", agency: "Al Habib Real Estate", rating: 5.0, tier: "vip", color_tag: "#4f8ef7", verified: 1, specialties: "All Societies" },
    { name: "Kamran Broker", phone: "03133006063", agency: "Independent", rating: 4.5, tier: "premium", color_tag: "#C0C0C0", verified: 1, specialties: "Latifabad, Qasimabad" },
    { name: "Abbas Akram", phone: "0315366440", agency: "Independent", rating: 4.2, tier: "premium", color_tag: "#C0C0C0", verified: 1, specialties: "Qasimabad" },
    { name: "Ali Estate", phone: "03114044584", agency: "Ali Estate Agency", rating: 4.3, tier: "premium", color_tag: "#C0C0C0", verified: 1, specialties: "Latifabad" },
    { name: "Mahmood Estate", phone: "03132698027", agency: "Mahmood Estate", rating: 4.0, tier: "premium", color_tag: "#C0C0C0", verified: 1, specialties: "Latifabad, Qasimabad" },
    { name: "Javed Bismillah Estate", phone: "03103190859", agency: "Bismillah Estate", rating: 4.2, tier: "premium", color_tag: "#C0C0C0", verified: 1, specialties: "Qasimabad" },
    { name: "Nazeer Broker", phone: "03453630811", agency: "Independent", rating: 4.0, tier: "premium", color_tag: "#C0C0C0", verified: 1, specialties: "Cantt Area" },
    { name: "Waseem Broker", phone: "03113026928", agency: "Independent", rating: 4.1, tier: "premium", color_tag: "#C0C0C0", verified: 1, specialties: "Latifabad" },
    { name: "Abdur Rehman", phone: "03133038040", agency: "Independent", rating: 4.0, tier: "premium", color_tag: "#C0C0C0", verified: 1, specialties: "Qasimabad" },
    { name: "JS Real Estate (Javed)", phone: "03103190859", agency: "JS Real Estate", rating: 4.3, tier: "premium", color_tag: "#C0C0C0", verified: 1, specialties: "All Areas" },
    { name: "Ahsan Broker", phone: "03153346028", agency: "Independent", rating: 3.5, tier: "standard", color_tag: "#CD7F32", verified: 0, specialties: "Qasimabad" },
    { name: "Awais Broker", phone: "03122461979", agency: "Independent", rating: 3.5, tier: "standard", color_tag: "#CD7F32", verified: 0, specialties: "Latifabad" },
    { name: "Rashid Broker", phone: "03103012123", agency: "Independent", rating: 3.5, tier: "standard", color_tag: "#CD7F32", verified: 0, specialties: "Latifabad" },
    { name: "Yousuf Broker", phone: "0332623373", agency: "Independent", rating: 3.5, tier: "standard", color_tag: "#CD7F32", verified: 0, specialties: "Qasimabad" },
    { name: "Ejaz Broker", phone: "03243311890", agency: "Independent", rating: 3.5, tier: "standard", color_tag: "#CD7F32", verified: 0, specialties: "Cantt" },
    { name: "Kamran (2)", phone: "03153771307", agency: "Independent", rating: 3.8, tier: "standard", color_tag: "#CD7F32", verified: 0, specialties: "Qasimabad" },
    { name: "Waqas Broker", phone: "03363019897", agency: "Independent", rating: 3.5, tier: "standard", color_tag: "#CD7F32", verified: 0, specialties: "Latifabad" },
    { name: "Abbas Broker", phone: "03132549823", agency: "Independent", rating: 3.5, tier: "standard", color_tag: "#CD7F32", verified: 0, specialties: "Latifabad" },
    { name: "Abdul Jabbar", phone: "03112116364", agency: "Independent", rating: 3.5, tier: "standard", color_tag: "#CD7F32", verified: 0, specialties: "Qasimabad" },
    { name: "Abdullah Memon", phone: "03163979081", agency: "Independent", rating: 3.5, tier: "standard", color_tag: "#CD7F32", verified: 0, specialties: "Qasimabad" },
    { name: "Ali Hassan Broker", phone: "033323171", agency: "Independent", rating: 3.5, tier: "standard", color_tag: "#CD7F32", verified: 0, specialties: "Latifabad" },
    { name: "Ali Hassan (2)", phone: "03056263195", agency: "Independent", rating: 3.5, tier: "standard", color_tag: "#CD7F32", verified: 0, specialties: "Latifabad" },
    { name: "Ata-ur-Rehman", phone: "03112113946", agency: "Independent", rating: 3.5, tier: "standard", color_tag: "#CD7F32", verified: 0, specialties: "Qasimabad" },
    { name: "Faisal Qaim", phone: "03008730964", agency: "Independent", rating: 3.5, tier: "standard", color_tag: "#CD7F32", verified: 0, specialties: "Cantt" },
    { name: "Sheikh Broker", phone: "031444239001", agency: "Independent", rating: 3.5, tier: "standard", color_tag: "#CD7F32", verified: 0, specialties: "Latifabad" },
    { name: "Raees Broker", phone: "03134257054", agency: "Independent", rating: 3.5, tier: "standard", color_tag: "#CD7F32", verified: 0, specialties: "Qasimabad" },
    { name: "Shahid Broker", phone: "0345253350", agency: "Independent", rating: 3.5, tier: "standard", color_tag: "#CD7F32", verified: 0, specialties: "Latifabad" },
    { name: "Raheel Qureshi", phone: "03443405489", agency: "Independent", rating: 3.5, tier: "standard", color_tag: "#CD7F32", verified: 0, specialties: "Qasimabad" },
    { name: "Hamid Broker", phone: "03138496345", agency: "Independent", rating: 3.5, tier: "standard", color_tag: "#CD7F32", verified: 0, specialties: "Latifabad" },
    { name: "Rehan Broker", phone: "03188117178", agency: "Independent", rating: 3.5, tier: "standard", color_tag: "#CD7F32", verified: 0, specialties: "Qasimabad" },
    { name: "Aamir Rana", phone: "03170834295", agency: "Independent", rating: 3.5, tier: "standard", color_tag: "#CD7F32", verified: 0, specialties: "Cantt" },
    { name: "Muhammad Broker", phone: "0300379010", agency: "Independent", rating: 3.5, tier: "standard", color_tag: "#CD7F32", verified: 0, specialties: "All Areas" },
    { name: "Shakeel Broker", phone: "03352304671", agency: "Independent", rating: 3.5, tier: "standard", color_tag: "#CD7F32", verified: 0, specialties: "Latifabad" },
    { name: "Azeem Broker", phone: "03133001948", agency: "Independent", rating: 3.5, tier: "standard", color_tag: "#CD7F32", verified: 0, specialties: "Qasimabad" },
    { name: "Furqan Broker", phone: "03002763101", agency: "Independent", rating: 3.5, tier: "standard", color_tag: "#CD7F32", verified: 0, specialties: "Latifabad" },
    { name: "Tariq Broker", phone: "03155669050", agency: "Independent", rating: 3.5, tier: "standard", color_tag: "#CD7F32", verified: 0, specialties: "Qasimabad" },
    { name: "Safdar Broker", phone: "03119304552", agency: "Independent", rating: 3.5, tier: "standard", color_tag: "#CD7F32", verified: 0, specialties: "Latifabad" },
    { name: "Aashiq Broker", phone: "03123213739", agency: "Independent", rating: 3.5, tier: "standard", color_tag: "#CD7F32", verified: 0, specialties: "Qasimabad" }
  ];

  // Insert societies
  for (const s of societies) {
    db.run(`INSERT INTO societies (name, name_urdu, location, type, rent_2bed_min, rent_2bed_max, rent_3bed_min, rent_3bed_max, sale_2bed_min, sale_2bed_max, sale_3bed_min, sale_3bed_max, sui_gas, water_supply, electricity, amenities, latitude, longitude, featured) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [s.name, s.name_urdu, s.location, s.type, s.rent_2bed_min||null, s.rent_2bed_max||null, s.rent_3bed_min||null, s.rent_3bed_max||null, s.sale_2bed_min||null, s.sale_2bed_max||null, s.sale_3bed_min||null, s.sale_3bed_max||null, s.sui_gas, s.water_supply, s.electricity, s.amenities, s.latitude, s.longitude, s.featured||0]
    );
  }
  console.log(`  [SEED] ${societies.length} societies inserted`);

  // Insert brokers
  for (const b of brokers) {
    db.run(`INSERT INTO brokers (name, phone, agency, rating, tier, specialties, color_tag, verified) VALUES (?,?,?,?,?,?,?,?)`,
      [b.name, b.phone, b.agency, b.rating, b.tier, b.specialties, b.color_tag, b.verified]
    );
  }
  console.log(`  [SEED] ${brokers.length} brokers inserted`);

  // Assign brokers to societies — VIP broker (id=1) is primary for ALL
  for (let sId = 1; sId <= societies.length; sId++) {
    db.run('INSERT INTO society_brokers (society_id, broker_id, is_primary) VALUES (?,?,?)', [sId, 1, 1]);
    const sec1 = ((sId - 1) % (brokers.length - 1)) + 2;
    db.run('INSERT INTO society_brokers (society_id, broker_id, is_primary) VALUES (?,?,?)', [sId, sec1, 0]);
    if (sId % 2 === 0) {
      const sec2 = (sId % (brokers.length - 1)) + 2;
      if (sec2 !== sec1) {
        db.run('INSERT INTO society_brokers (society_id, broker_id, is_primary) VALUES (?,?,?)', [sId, sec2, 0]);
      }
    }
  }
  console.log(`  [SEED] Society-broker assignments created`);

  // Create sample listings for each society
  let listingCount = 0;
  for (let i = 0; i < societies.length; i++) {
    const sId = i + 1;
    const s = societies[i];
    if (s.rent_2bed_min) {
      db.run(`INSERT INTO listings (society_id, broker_id, title, type, bedrooms, price, price_type, description, status) VALUES (?,?,?,?,?,?,?,?,?)`,
        [sId, 1, `2-Bed Apartment For Rent — ${s.name}`, 'rent', 2, s.rent_2bed_max, 'monthly', `${s.type} for rent in ${s.location}. ${s.amenities}`, 'active']);
      listingCount++;
    }
    if (s.rent_3bed_min) {
      db.run(`INSERT INTO listings (society_id, broker_id, title, type, bedrooms, price, price_type, description, status) VALUES (?,?,?,?,?,?,?,?,?)`,
        [sId, 1, `3-Bed Apartment For Rent — ${s.name}`, 'rent', 3, s.rent_3bed_max, 'monthly', `Spacious 3-bed in ${s.location}. ${s.amenities}`, 'active']);
      listingCount++;
    }
    if (s.sale_2bed_min) {
      db.run(`INSERT INTO listings (society_id, broker_id, title, type, bedrooms, price, price_type, description, status) VALUES (?,?,?,?,?,?,?,?,?)`,
        [sId, 1, `2-Bed Apartment For Sale — ${s.name}`, 'sale', 2, s.sale_2bed_max, 'total', `Prime 2-bed for sale in ${s.location}. ${s.amenities}`, 'active']);
      listingCount++;
    }
    if (s.sale_3bed_min) {
      db.run(`INSERT INTO listings (society_id, broker_id, title, type, bedrooms, price, price_type, description, status) VALUES (?,?,?,?,?,?,?,?,?)`,
        [sId, 1, `3-Bed Apartment For Sale — ${s.name}`, 'sale', 3, s.sale_3bed_max, 'total', `Premium 3-bed for sale in ${s.location}. ${s.amenities}`, 'active']);
      listingCount++;
    }
  }
  console.log(`  [SEED] ${listingCount} listings created`);

  saveDb(db);
  console.log('\n  ★ Database seeded successfully! ★\n');
}

seed().catch(console.error);
