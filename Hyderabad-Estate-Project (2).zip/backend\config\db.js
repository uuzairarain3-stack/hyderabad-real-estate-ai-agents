const initSqlJs = require('sql.js');
const path = require('path');
const fs = require('fs');

const DB_PATH = path.join(__dirname, '..', '..', 'estate-vip.db');
let db;

async function getDb() {
  if (db) return db;
  const SQL = await initSqlJs();
  if (fs.existsSync(DB_PATH)) {
    const buf = fs.readFileSync(DB_PATH);
    db = new SQL.Database(buf);
  } else {
    db = new SQL.Database();
  }
  db._path = DB_PATH;
  return db;
}

function saveDb(database) {
  const data = database.export();
  fs.writeFileSync(database._path, Buffer.from(data));
}

function initDb() {
  // We do this synchronously during startup using a small helper
  return new Promise(async (resolve, reject) => {
    try {
      const d = await getDb();
      d.run(`
        CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          email TEXT UNIQUE NOT NULL,
          password TEXT NOT NULL,
          phone TEXT,
          role TEXT DEFAULT 'user',
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS societies (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          name_urdu TEXT,
          location TEXT NOT NULL,
          type TEXT,
          description TEXT,
          rent_2bed_min INTEGER,
          rent_2bed_max INTEGER,
          rent_3bed_min INTEGER,
          rent_3bed_max INTEGER,
          sale_2bed_min INTEGER,
          sale_2bed_max INTEGER,
          sale_3bed_min INTEGER,
          sale_3bed_max INTEGER,
          sui_gas TEXT,
          water_supply TEXT,
          electricity TEXT,
          amenities TEXT,
          latitude REAL DEFAULT 25.39,
          longitude REAL DEFAULT 68.35,
          image_url TEXT,
          featured INTEGER DEFAULT 0,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS brokers (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          name_urdu TEXT,
          phone TEXT NOT NULL,
          agency TEXT,
          rating REAL DEFAULT 3.0,
          tier TEXT DEFAULT 'standard',
          specialties TEXT,
          color_tag TEXT DEFAULT '#4A90D9',
          verified INTEGER DEFAULT 0,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS society_brokers (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          society_id INTEGER NOT NULL,
          broker_id INTEGER NOT NULL,
          is_primary INTEGER DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS listings (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          society_id INTEGER,
          broker_id INTEGER,
          title TEXT NOT NULL,
          type TEXT,
          bedrooms INTEGER,
          price INTEGER,
          price_type TEXT,
          area_sqft INTEGER,
          description TEXT,
          image_url TEXT,
          status TEXT DEFAULT 'active',
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS housing_societies (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          location TEXT NOT NULL,
          total_plots TEXT,
          available_sizes TEXT,
          estimated_rates TEXT,
          road_width TEXT,
          sui_gas TEXT,
          electricity TEXT,
          masjid TEXT,
          amenities TEXT,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS chat_sessions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER,
          session_id TEXT,
          role TEXT,
          content TEXT,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
      `);
      saveDb(d);
      console.log('  [DB] Tables initialized');
      resolve();
    } catch (err) { reject(err); }
  });
}

// Helper: run a query and return all rows as objects
function queryAll(database, sql, params = []) {
  const stmt = database.prepare(sql);
  stmt.bind(params);
  const rows = [];
  while (stmt.step()) {
    rows.push(stmt.getAsObject());
  }
  stmt.free();
  return rows;
}

// Helper: run a single-row query
function queryOne(database, sql, params = []) {
  const rows = queryAll(database, sql, params);
  return rows[0] || null;
}

// Helper: run a write query and return lastInsertRowid
function runQuery(database, sql, params = []) {
  database.run(sql, params);
  saveDb(database);
  const row = queryOne(database, 'SELECT last_insert_rowid() as id');
  return { lastInsertRowid: row ? row.id : null };
}

module.exports = { getDb, initDb, saveDb, queryAll, queryOne, runQuery };
