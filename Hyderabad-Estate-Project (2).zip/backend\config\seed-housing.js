// Seed 24 housing/plot societies into housing_societies table
const { getDb, initDb, saveDb } = require('./db');

const societies = [
  {
    name: "GULSHAN-E-ZEALPAK COOPERATIVE HOUSING SOCIETY",
    location: "SITE Area / National Highway Link Road, Hyderabad",
    total_plots: "500 Total Plots (120 Sq Yds: 100, 240 Sq Yds: 250, 400 Sq Yds: 150)",
    available_sizes: "240 Sq Yds | 400 Sq Yds",
    estimated_rates: "240 Sq Yds: PKR 1.40 Cr - 2.50 Cr (Plot) / PKR 3.80 - 4.50 Cr (House)\n400 Sq Yds: PKR 2.80 Cr - 3.90 Cr",
    road_width: "Main Roads 60 Feet, Internal Streets 40 Feet",
    sui_gas: "Fully Active (24/7 High Pressure Supply)",
    electricity: "Active Feeder (1-2 Hours Loadshedding)",
    masjid: "Central Jamia Masjid within Society + 2 Sector Masjids",
    amenities: "Society Central Park, Gated Security, Playgrounds, Commercial Market"
  },
  {
    name: "SAIMA DOWNTOWN",
    location: "Main Hyderabad Bypass (Near Kababjees)",
    total_plots: "1800 Total Plots (120 Sq Yds: 600, 160 Sq Yds: 400, 200 Sq Yds: 500, 240 Sq Yds: 300)",
    available_sizes: "120 Sq Yds | 160 Sq Yds | 200 Sq Yds | 240 Sq Yds",
    estimated_rates: "120 Sq Yds: PKR 1.10 Cr - 1.35 Cr\n160 & 200 Sq Yds: PKR 1.85 Cr - 2.45 Cr\n240 Sq Yds: PKR 2.90 Cr - 3.50 Cr",
    road_width: "Main Boulevard 100-120 Feet, Streets 40 Feet",
    sui_gas: "Active Main Line Connection",
    electricity: "24/7 Power Backup / Negligible Loadshedding",
    masjid: "Grand Mosque Under Construction + Near Main Highway Jamia Masjid",
    amenities: "Theme Park, Gated Security, Family Club, Underground Utilities"
  },
  {
    name: "PALM VILLAGE / PALM ROYAL RESIDENCY",
    location: "Main Hyderabad Bypass",
    total_plots: "1200 Total Plots (150 Sq Yds: 400, 200 Sq Yds: 400, 240 Sq Yds: 250, 400 Sq Yds: 150)",
    available_sizes: "150 Sq Yds | 200 Sq Yds | 240 Sq Yds | 400 Sq Yds",
    estimated_rates: "150 Sq Yds: PKR 1.45 Cr - 1.65 Cr\n200 & 240 Sq Yds: PKR 2.10 Cr - 2.85 Cr\n400 Sq Yds: PKR 4.25 Cr - 5.10 Cr",
    road_width: "Main Boulevard 120 Feet, Streets 40-50 Feet",
    sui_gas: "Active Pipeline Connection",
    electricity: "Gated Society Grid (1 Hour Loadshedding)",
    masjid: "Central Mosque Inside + Nearby Highway Jama Masjid",
    amenities: "Royal Family Park, Green Belts, Commercial Strip, CCTV Security"
  },
  {
    name: "CITIZEN COLONY",
    location: "Qasimabad, Hyderabad",
    total_plots: "850 Total Plots (240 Sq Yds: 350, 300 Sq Yds: 300, 400 Sq Yds: 200)",
    available_sizes: "240 Sq Yds | 300 Sq Yds | 400 Sq Yds",
    estimated_rates: "240 & 300 Sq Yds: PKR 2.60 Cr - 3.75 Cr\n400 Sq Yds: PKR 3.80 Cr - 5.20 Cr",
    road_width: "Main Commercial Road 80 Feet, Internal Streets 40 Feet",
    sui_gas: "Fully Active (24/7 Gas Flow)",
    electricity: "Low Loadshedding Zone (1-2 Hours)",
    masjid: "2 Active Masjids Inside Society",
    amenities: "Citizen Community Park, Commercial Market, Private Security"
  },
  {
    name: "REVENUE EMPLOYEES COOPERATIVE HOUSING SOCIETY",
    location: "Qasimabad, Hyderabad",
    total_plots: "950 Total Plots (180 Sq Yds: 400, 200 Sq Yds: 350, 240 Sq Yds: 200)",
    available_sizes: "180 Sq Yds | 200 Sq Yds | 240 Sq Yds",
    estimated_rates: "180 Sq Yds: PKR 75 Lac - 95 Lac\n200 & 240 Sq Yds: PKR 1.25 Cr - 1.65 Cr",
    road_width: "35 to 50 Feet Wide Streets",
    sui_gas: "Fully Active Direct Supply",
    electricity: "Active (1-2 Hours Loadshedding)",
    masjid: "Jamia Masjid Located at Sector Center",
    amenities: "Sector Family Park, Schools Nearby, Community Center"
  },
  {
    name: "ROHAAN FARAZ VILLAS",
    location: "Main Hyderabad Bypass",
    total_plots: "600 Total Plots (120 Sq Yds: 350, 200 Sq Yds: 250)",
    available_sizes: "120 Sq Yds | 200 Sq Yds",
    estimated_rates: "120 Sq Yds: PKR 70 Lac - 88 Lac\n200 Sq Yds: PKR 1.20 Cr - 1.50 Cr",
    road_width: "Main Road 50 Feet, Streets 40 Feet",
    sui_gas: "Main Pipeline Installed",
    electricity: "Active Line (2 Hours Loadshedding)",
    masjid: "Sector Masjid Built Inside",
    amenities: "Children Play Park, Gated Boundary, Security Guard"
  },
  {
    name: "SADIQ LIVNA",
    location: "Hyderabad Bypass Zone",
    total_plots: "1100 Total Plots (120 Sq Yds: 500, 200 Sq Yds: 400, 400 Sq Yds: 200)",
    available_sizes: "120 Sq Yds | 200 Sq Yds | 400 Sq Yds",
    estimated_rates: "120 Sq Yds: PKR 45 Lac - 60 Lac\n200 Sq Yds: PKR 75 Lac - 1.05 Cr\n400 Sq Yds: PKR 1.80 Cr - 2.40 Cr",
    road_width: "60 Feet Main Boulevard, 40 Feet Streets",
    sui_gas: "Pipeline Connections Available",
    electricity: "Active Line (2-3 Hours Loadshedding)",
    masjid: "Society Mosque + Close to Bypass Main Mosque",
    amenities: "Central Park Area, Wide Green Belts, Gated Main Gate"
  },
  {
    name: "GULISTAN-E-SARMAST HOUSING SCHEME (HDA)",
    location: "Latifabad / Badin Road Link, Hyderabad",
    total_plots: "4500 Total Plots (80 Sq Yds: 1500, 120 Sq Yds: 1800, 240 Sq Yds: 800, 400 Sq Yds: 400)",
    available_sizes: "80 Sq Yds | 120 Sq Yds | 240 Sq Yds | 400 Sq Yds",
    estimated_rates: "80 Sq Yds: PKR 12 Lac - 20 Lac\n120 Sq Yds: PKR 22 Lac - 38 Lac\n240 & 400 Sq Yds: PKR 45 Lac - 85 Lac",
    road_width: "Main Roads 100 Feet, Sector Streets 30-40 Feet",
    sui_gas: "Under Process (Approval Stage)",
    electricity: "Active Line (3-4 Hours Loadshedding)",
    masjid: "Sector Masjids Reserved in Every Block",
    amenities: "Multiple Sector Parks Reserved, HDA Developed Grounds"
  },
  {
    name: "NEW HYDERABAD CITY",
    location: "Main Hyderabad Bypass / Bypass Link Road",
    total_plots: "1500 Total Plots (120 Sq Yds: 1000, 400 Sq Yds: 500)",
    available_sizes: "120 Sq Yds | 400 Sq Yds",
    estimated_rates: "120 Sq Yds: PKR 20 Lac - 32 Lac\n400 Sq Yds: PKR 70 Lac - 95 Lac",
    road_width: "80 Feet Main Boulevard, 40 Feet Streets",
    sui_gas: "Network Under Development",
    electricity: "Active Feeders (3 Hours Loadshedding)",
    masjid: "Mosque Plot Reserved at Central Block",
    amenities: "Central Park Plot, Commercial Zone, Plantation Lines"
  },
  {
    name: "DAMAN-E-KOHSAR",
    location: "Latifabad Extension / Kohsar, Hyderabad",
    total_plots: "2200 Total Plots (120 Sq Yds: 1000, 240 Sq Yds: 800, 400 Sq Yds: 400)",
    available_sizes: "120 Sq Yds | 240 Sq Yds | 400 Sq Yds",
    estimated_rates: "120 Sq Yds: PKR 18 Lac - 30 Lac\n240 Sq Yds: PKR 60 Lac - 85 Lac\n400 Sq Yds: PKR 1.10 Cr - 1.50 Cr",
    road_width: "Main Road 100 Feet, Streets 35 Feet",
    sui_gas: "Selective Blocks Active",
    electricity: "Active Lines (2-3 Hours Loadshedding)",
    masjid: "Jamia Masjid Active inside Sector 1",
    amenities: "Hillview Public Park, Local Shops, Public School Nearby"
  },
  {
    name: "NAQASH VILLAS (PHASE 1 & 2)",
    location: "Qasimabad Link Road",
    total_plots: "750 Total Plots (120 Sq Yds: 450, 200 Sq Yds: 300)",
    available_sizes: "120 Sq Yds | 200 Sq Yds",
    estimated_rates: "120 Sq Yds: PKR 85 Lac - 1.10 Cr\n200 Sq Yds: PKR 1.45 Cr - 1.90 Cr",
    road_width: "Main Access 50 Feet, Streets 40 Feet",
    sui_gas: "Fully Active Gas Line",
    electricity: "Active Feeder (1-2 Hours Loadshedding)",
    masjid: "Naqash Jamia Masjid Inside",
    amenities: "Gated Society Park, Commercial Market Access"
  },
  {
    name: "INK CITY (PHASE 1 & 2)",
    location: "Hyderabad Bypass Zone",
    total_plots: "900 Total Plots (150 Sq Yds: 500, 200 Sq Yds: 400)",
    available_sizes: "150 Sq Yds | 200 Sq Yds",
    estimated_rates: "150 Sq Yds: PKR 95 Lac - 1.20 Cr\n200 Sq Yds: PKR 1.30 Cr - 1.65 Cr",
    road_width: "60 Feet Main Avenue, 40 Feet Internal Roads",
    sui_gas: "Active Sui Gas Network",
    electricity: "Active (2 Hours Loadshedding)",
    masjid: "Phase 1 Active Masjid + Phase 2 Masjid Plot",
    amenities: "Family Park, Boundary Wall, Security Posts"
  },
  {
    name: "ZULFIQAR ROYAL RESIDENCY (ZULFIQAR HOMES)",
    location: "Qasimabad / Bypass Access",
    total_plots: "650 Total Plots (120 Sq Yds: 400, 200 Sq Yds: 250)",
    available_sizes: "120 Sq Yds | 200 Sq Yds",
    estimated_rates: "120 Sq Yds: PKR 95 Lac - 1.25 Cr\n200 Sq Yds: PKR 1.50 Cr - 2.05 Cr",
    road_width: "40 Feet Gated Streets",
    sui_gas: "Fully Active Gas Connection",
    electricity: "Active Feeder (1 Hour Loadshedding)",
    masjid: "Central Masjid Built Inside Gate",
    amenities: "Gated Entrance, Children Park, Private Guarding"
  },
  {
    name: "GULSHAN-E-SAJJAD",
    location: "Near Qasimabad Bypass",
    total_plots: "800 Total Plots (200 Sq Yds: 500, 400 Sq Yds: 300)",
    available_sizes: "200 Sq Yds | 400 Sq Yds",
    estimated_rates: "200 Sq Yds: PKR 1.20 Cr - 1.70 Cr\n400 Sq Yds: PKR 2.50 Cr - 3.20 Cr",
    road_width: "40 to 50 Feet Wide Streets",
    sui_gas: "Active Sui Gas Line",
    electricity: "Active Feeder (1-2 Hours Loadshedding)",
    masjid: "Sajjad Jamia Masjid Active",
    amenities: "Community Park, Commercial Market, Peaceful Area"
  },
  {
    name: "HYDERABAD-BADIN ROAD SCHEMES",
    location: "Main Badin Road, Hyderabad",
    total_plots: "1600 Total Plots (80 Sq Yds: 700, 120 Sq Yds: 900)",
    available_sizes: "80 Sq Yds | 120 Sq Yds",
    estimated_rates: "80 Sq Yds: PKR 14 Lac - 22 Lac\n120 Sq Yds: PKR 28 Lac - 42 Lac",
    road_width: "Main 60 Feet, Streets 30-40 Feet",
    sui_gas: "Underground Pipeline Planned",
    electricity: "Active Line (3-4 Hours Loadshedding)",
    masjid: "Mosque Built Near Main Entrance",
    amenities: "Corner Park Plot, Highway Connectivity"
  },
  {
    name: "GULSHAN-E-SHAHBAZ",
    location: "Jamshoro Road / Bypass Junction, Hyderabad",
    total_plots: "2800 Total Plots (120 Sq Yds: 1200, 200 Sq Yds: 1000, 400 Sq Yds: 600)",
    available_sizes: "120 Sq Yds | 200 Sq Yds | 400 Sq Yds",
    estimated_rates: "120 Sq Yds: PKR 28 Lac - 45 Lac\n200 Sq Yds: PKR 50 Lac - 85 Lac\n400 Sq Yds: PKR 1.10 Cr - 1.80 Cr",
    road_width: "Commercial Boulevard 100 Feet, Streets 40 Feet",
    sui_gas: "Under Process / Limited Sectors Active",
    electricity: "Active Line (3-4 Hours Loadshedding)",
    masjid: "Central Jamia Masjid Built near Main Gate",
    amenities: "Central Park Land, Underground WASA Water Project"
  },
  {
    name: "AL-MUSTAFA TOWN",
    location: "Wadhu Wah Road, Qasimabad",
    total_plots: "700 Total Plots (120 Sq Yds: 400, 200 Sq Yds: 300)",
    available_sizes: "120 Sq Yds | 200 Sq Yds",
    estimated_rates: "120 Sq Yds: PKR 55 Lac - 85 Lac\n200 Sq Yds: PKR 1.00 Cr - 1.50 Cr",
    road_width: "Main Access 60 Feet, Internal Streets 35-40 Feet",
    sui_gas: "Fully Active (High Pressure Gas)",
    electricity: "Active (1-2 Hours Loadshedding)",
    masjid: "2 Active Masjids inside Town",
    amenities: "2 Family Parks, Gated Entrance, WASA Filtered Line"
  },
  {
    name: "AL-RAHIM TOWN (PHASE 2)",
    location: "Hatri Bypass Link Road",
    total_plots: "850 Total Plots (120 Sq Yds: 500, 200 Sq Yds: 350)",
    available_sizes: "120 Sq Yds | 200 Sq Yds",
    estimated_rates: "120 Sq Yds: PKR 35 Lac - 55 Lac\n200 Sq Yds: PKR 60 Lac - 1.00 Cr",
    road_width: "Main Gate Road 60 Feet, Sector Streets 40 Feet",
    sui_gas: "Active Main Line Connection",
    electricity: "Active (2-3 Hours Loadshedding)",
    masjid: "Jamia Masjid Built at Sector Center",
    amenities: "Park Plot Reserved, Main Security Gate, Boring Water"
  },
  {
    name: "AL-HABEEB CITY",
    location: "Airport Road / Scheme 45 Area",
    total_plots: "1300 Total Plots (120 Sq Yds: 600, 200 Sq Yds: 450, 400 Sq Yds: 250)",
    available_sizes: "120 Sq Yds | 200 Sq Yds | 400 Sq Yds",
    estimated_rates: "120 Sq Yds: PKR 40 Lac - 65 Lac\n200 Sq Yds: PKR 70 Lac - 1.10 Cr\n400 Sq Yds: PKR 1.15 Cr - 1.75 Cr",
    road_width: "40 Feet & 50 Feet Internal Road Network",
    sui_gas: "Pipeline Supply Available",
    electricity: "Active (2 Hours Loadshedding)",
    masjid: "Central Mosque Plot Reserved & Active Prayer Hall",
    amenities: "Community Center Plot, Reserved Green Park"
  },
  {
    name: "GULSHAN-E-IQBAL",
    location: "Qasimabad Sector 2",
    total_plots: "1100 Total Plots (200 Sq Yds: 700, 400 Sq Yds: 400)",
    available_sizes: "200 Sq Yds | 400 Sq Yds",
    estimated_rates: "200 Sq Yds: PKR 1.05 Cr - 1.80 Cr\n400 Sq Yds: PKR 2.05 Cr - 3.45 Cr",
    road_width: "40, 60 & 80 Feet Wide Roads",
    sui_gas: "Fully Active (24/7 Supply)",
    electricity: "Active (Low Loadshedding Zone)",
    masjid: "Multiple Active Masjids within Walking Distance",
    amenities: "Family Park, Main Commercial Market, Direct WASA Water"
  },
  {
    name: "QASIMABAD PHASE 1 & 2",
    location: "Main Boulevard Zone, Qasimabad",
    total_plots: "2500 Total Plots (200 Sq Yds: 1200, 400 Sq Yds: 900, 600 Sq Yds: 400)",
    available_sizes: "200 Sq Yds | 400 Sq Yds | 600 Sq Yds",
    estimated_rates: "200 Sq Yds: PKR 1.35 Cr - 2.20 Cr\n400 Sq Yds: PKR 2.45 Cr - 4.25 Cr",
    road_width: "Main Boulevard 120 Feet, Sub-roads 40-60 Feet",
    sui_gas: "Fully Active High-Pressure Gas",
    electricity: "Fully Active Feeders (Minimal Loadshedding)",
    masjid: "Central Jamia Masjid + Multiple Block Masjids",
    amenities: "Multiple Developed Parks, Food Street, Banking Hub"
  },
  {
    name: "MEHRAN TOWN",
    location: "Near Bulk Water Works, Qasimabad",
    total_plots: "600 Total Plots (120 Sq Yds: 350, 200 Sq Yds: 250)",
    available_sizes: "120 Sq Yds | 200 Sq Yds",
    estimated_rates: "120 Sq Yds: PKR 45 Lac - 70 Lac\n200 Sq Yds: PKR 80 Lac - 1.30 Cr",
    road_width: "35 to 45 Feet Streets",
    sui_gas: "Active Gas Line",
    electricity: "Active (2 Hours Loadshedding)",
    masjid: "Sector Masjid Active Inside",
    amenities: "Gated Entrance, Primary School Plot, Nearby Water Works"
  },
  {
    name: "GREEN CITY",
    location: "Jamshoro Bypass Interchange",
    total_plots: "950 Total Plots (120 Sq Yds: 550, 200 Sq Yds: 400)",
    available_sizes: "120 Sq Yds | 200 Sq Yds",
    estimated_rates: "120 Sq Yds: PKR 30 Lac - 48 Lac\n200 Sq Yds: PKR 53 Lac - 90 Lac",
    road_width: "40 Feet Road with Plantation Belts",
    sui_gas: "Underground Network Planned",
    electricity: "Active (3 Hours Loadshedding)",
    masjid: "Mosque Under Construction Inside Scheme",
    amenities: "Green Belt Plantation, Active Ground Boring Water"
  },
  {
    name: "TEACHERS SOCIETY",
    location: "Qasimabad Extension Zone",
    total_plots: "1000 Total Plots (120 Sq Yds: 400, 200 Sq Yds: 400, 400 Sq Yds: 200)",
    available_sizes: "120 Sq Yds | 200 Sq Yds | 400 Sq Yds",
    estimated_rates: "120 Sq Yds: PKR 50 Lac - 75 Lac\n200 Sq Yds: PKR 90 Lac - 1.40 Cr\n400 Sq Yds: PKR 1.70 Cr - 2.30 Cr",
    road_width: "Main Access 50 Feet, Streets 40 Feet",
    sui_gas: "Fully Active Gas Line",
    electricity: "Active Feeder (2 Hours Loadshedding)",
    masjid: "Central Jamia Masjid Active",
    amenities: "Teachers Club, Gated Boundary, Educational Institutes Nearby"
  }
];

async function seed() {
  await initDb();
  const db = await getDb();

  // Clear existing housing_societies data
  db.run('DELETE FROM housing_societies');
  console.log('  ✓ Cleared existing housing societies');

  let count = 0;
  for (const s of societies) {
    db.run(
      `INSERT INTO housing_societies
        (name, location, total_plots, available_sizes, estimated_rates, road_width, sui_gas, electricity, masjid, amenities)
       VALUES (?,?,?,?,?,?,?,?,?,?)`,
      [s.name, s.location, s.total_plots, s.available_sizes, s.estimated_rates,
       s.road_width, s.sui_gas, s.electricity, s.masjid, s.amenities]
    );
    count++;
  }

  const { saveDb } = require('./db');
  saveDb(db);
  console.log(`  ✓ Seeded ${count} housing societies successfully`);
}

seed().catch(console.error);
