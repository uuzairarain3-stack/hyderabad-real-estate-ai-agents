// One-shot script: fix Zahid Hussain phone number in the live DB
const { getDb, initDb, saveDb, runQuery } = require('./db');

async function fix() {
  await initDb();
  const db = await getDb();
  db.run("UPDATE brokers SET phone = '03013501356' WHERE name LIKE '%Zahid%'");
  saveDb(db);
  console.log('  ✓ Zahid Hussain phone updated to 03013501356');
}
fix().catch(console.error);
